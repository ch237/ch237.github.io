clear all;close all;
%load('/Users/changwei/Documents/Research/othercode/demo_20news/data/20news_data.mat')
load /Users/changwei/Documents/Research/data/TopicModelingPreprocessing/ProcessedData/preprocessed20News.mat
[rows1, cols1, vals1]=find(wordsTrain);
[rows2, cols2, vals2]=find(wordsTest);
cols2=cols2+size(wordsTrain,2);
rows=[rows1;rows2];
cols=[cols1;cols2];
id=[cols,rows];
xi=[vals1;vals2];
labels=[labelsTrain;labelsTest];
doc2aid=containers.Map;
aid2docid=containers.Map;
aid2docnum=containers.Map;
for i=1:length(labels)
    doc2aid(num2str(i))=labels(i);
    if ~isKey(aid2docid,num2str(labels(i)))
        aid2docid(num2str(labels(i)))=i;
        aid2docnum(num2str(labels(i)))=1;
    else
        aid2docid(num2str(labels(i)))=[aid2docid(num2str(labels(i))),i];
        aid2docnum(num2str(labels(i)))=aid2docnum(num2str(labels(i)))+1;
    end
end
save 20news_xiid xi id doc2aid aid2docid aid2docnum labelsToGroup
load 20news_xiid
hierarchical_onelayer;