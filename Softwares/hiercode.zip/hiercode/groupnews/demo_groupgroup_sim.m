load('results_hier_final.mat')
G_reorder=zeros(size(G));
order=zeros(20,1);
idx=0;
for i=1:7
    rowid=affid2aid(num2str(i));
    N=length(rowid);
    for j=1:N
        G_reorder(idx+j,:)=G(rowid(j),:);
        order(idx+j)=rowid(j);
    end
    idx=idx+N;
end


Gnorm_reorder=G_reorder./(repmat(sqrt(sum(G_reorder.^2,2)),1,R));
GG_reorder=1-pdist2(Gnorm_reorder,Gnorm_reorder,'cosine');

figure,imagesc(GG_reorder)
colorStr=['k','m','y','r','g','b','c'];
for i_=1:20
    i=order(i_);
    splitStr=strsplit(labelsToGroup{i},'.');
    affidtmp=aid2affid(num2str(i));
    colortmp=colorStr(affidtmp);
    if affidtmp==3
        colortmp=[0.3,0.5,1];
    elseif affidtmp==1
        colortmp=[0.5,0.8,0.5];
    end
    text(-1,i_,[num2str(i)],'fontsize',12,'fontweight','bold','color',colortmp);
%     text(-2,i,[num2str(affidtmp),': ',splitStr{end-1},'.',splitStr{end}],'fontsize',12,'fontweight','bold','color',colortmp);
    text(i_-0.4,0,[num2str(i)],'fontsize',12,'fontweight','bold','color',colortmp);
end
set(gca,'ytick',[])
set(gca,'xtick',[])

FG_reorder=1-pdist2(Fnorm,Gnorm_reorder,'cosine');
figure,imagesc(FG_reorder')
colorStr=['k','m','y','r','g','b','c'];
for i_=1:20
    i=order(i_);
    splitStr=strsplit(labelsToGroup{i},'.');
    affidtmp=aid2affid(num2str(i));
    colortmp=colorStr(affidtmp);
    if affidtmp==3
        colortmp=[0.3,0.5,1];
    elseif affidtmp==1
        colortmp=[0.5,0.8,0.5];
    end
%     text(-0.5,i,[splitStr{end-1},'.',splitStr{end}],'fontsize',12,'fontweight','bold','color',colortmp);
text(0,i_,[num2str(i)],'fontsize',12,'fontweight','bold','color',colortmp);
end
for affidtmp=1:7
    colortmp=colorStr(affidtmp);
    if affidtmp==3
        colortmp=[0.3,0.5,1];
    elseif affidtmp==1
        colortmp=[0.5,0.8,0.5];
    end
    text(affidtmp-0.5,0, id2aff(num2str(affidtmp)),'fontsize',12,'fontweight','bold','color',colortmp);
end
set(gca,'ytick',[])
set(gca,'xtick',[])