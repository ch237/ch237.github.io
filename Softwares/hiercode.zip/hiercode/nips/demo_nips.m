clear all;close all;
% load nips_1-17
% disp('dataloaded')
% 
% [rows, cols, xi]=find(counts);
% id=[cols,rows];
% ND=size(counts,2);
% NF=length(authors_names);
% 
% labels=cell(1,ND);
% doc2aid=containers.Map;
% for i=1:ND
%     [row,labels{i}]=find(docs_authors(i,:));
%     doc2aid(num2str(i))=labels{i};
% end
% aid2docid=containers.Map;
% aid2docnum=containers.Map;
% for i=1:NF
%     [idtmp,col]=find(docs_authors(:,i));
%     aid2docid(num2str(i))=idtmp;
%     aid2docnum(num2str(i))=length(idtmp);
% end
% 
% vocabulary=words;
% labelsToGroup=authors_names;
% save nips_xiid xi id doc2aid aid2docid aid2docnum labelsToGroup vocabulary
load nips_xiid
% hierarchical
% hierarchical_onelayer;
nonhierarchical