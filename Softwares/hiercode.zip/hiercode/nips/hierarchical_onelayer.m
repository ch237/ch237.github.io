testfrac=0.1;
[xitrain, idtrain, xitest,idtest]=datasplit(xi,id,testfrac);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%parameter init
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ND=max(id(:,1));%# of docs
NW=max(id(:,2));%# of words
alpha=0.1;R=100;
U = sampleDirMat(alpha*ones(1,NW),R)';
c=1;epsi=1/R;
qr=betarnd(c*epsi*ones(1,R),c*(1-epsi)*ones(1,R));
% qr=0.5*ones(1,R);
s=1;beta1=1;beta0=1;

% doc2group=containers.Map;
% group2doc=containers.Map;
% group2docnum=containers.Map;

NF=size(aid2docid,1);%# of falcuty

Df=zeros(NF,1);
for i=1:NF
    Df(i)=aid2docnum(num2str(i));
end


G=zeros(NF,R);%falcuty feature
for i=1:NF
    G(i,:)=gamrnd(s,1/beta0/Df(i));
end
V=zeros(ND,R);
Vjrf=cell(1,ND);
for i=1:ND
    aidx=doc2aid(num2str(i));
    sVcurrent=zeros(1,R);
    Vjrf{i}=zeros(length(aidx),R);
    for j=1:length(aidx)
        sVcurrent=G(aidx(j),:);
%         sVtmp=sVtmp+sVcurrent;
        Vjrf{i}(j,:)=gamrnd(sVcurrent,qr/(1-qr));
    end
%     V(i,:)=gamrnd(sVtmp,qr/(1-qr));
    V(i,:)=sum(Vjrf{i},1);
end

iterMax=100;
aidx_cell=docauthorsearch(doc2aid,ND);

ell_fr=zeros(NF,R);
Gs=s.*ones(NF,R);%shape parameter for G
eval=zeros(1,iterMax);
for iter=1:iterMax
    tic    
    sufstat=computeSufStat(xitrain,idtrain,U,V,Vjrf,alpha,G,NF,aidx_cell);
    for r=1:R
        U(:,r)=sampleDirMat(sufstat{1}(:,r)',1)';
%         V(:,r)=gamrnd(sufstat{2}(:,r),qr(r));
    end
    for i=1:ND
        Vjrfshape=sufstat{2}{i};
        Vjrf{i}=gamrnd(Vjrfshape,repmat(qr,size(Vjrfshape,1),1));
        V(i,:)=sum(Vjrf{i},1);
    end
    qr=betarnd(c*epsi+sufstat{3},c*(1-epsi)+sufstat{4});
    
    for i=1:NF
        ell_fr(i,:)=CRT(sufstat{5}(i,:),Df(i)*G(i,:));
        for r=1:R
            G(i,r)=gamrnd(Gs(i,r)+ell_fr(i,r),1/(beta0-Df(i)*log(1-qr(r))));
        end
    end
    
    eval(iter)=loglike(xitest,idtest,U,V);
    timeintvl=toc;
    fprintf('iteration= %d;loglikelihood= %f,timePerIter=%f\n', iter, eval(iter),timeintvl);
    
end

W_outputN=20;
WO=vocabulary;
[Topics]=OutputTopics(U,WO,W_outputN)

Gnorm=G./(repmat(sqrt(sum(G.^2,2)),1,R));
GG=1-pdist2(Gnorm,Gnorm,'cosine');
% GG=G*G';
% FF=F*F';
simN=20;
aidsearch=1754;%2309;%2336;%127;%765;%983;%1127;
[simval aidout]=sort(GG(aidsearch,:),'descend');
for i=1:simN
    disp(labelsToGroup{aidout(i)});
end

[val topicid]=sort(G(aidsearch,:).*qr,'descend');
for i=1:10
    disp(Topics{topicid(i)})
end