testfrac=0.1;
[xitrain, idtrain, xitest,idtest]=datasplit(xi,id,testfrac);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%parameter init
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ND=max(id(:,1));%# of docs
NW=max(id(:,2));%# of words
alpha=0.1;R=100;
U = sampleDirMat(alpha*ones(1,NW),R)';
c=1;epsi=1/R;
qr=betarnd(c*epsi*ones(1,R),c*(1-epsi)*ones(1,R));
% qr=betarnd(c*epsi*ones(1,R),c*(1-epsi)*ones(1,R));
V=zeros(ND,R);
s=1;
for i=1:ND
    V(i,:)=gamrnd(s,qr/(1-qr));
end

iterMax=50;
for iter=1:iterMax
    tic    
    sufstat=computeSufStat_nohierarch(xitrain,idtrain,U,V,alpha);
    for r=1:R
        U(:,r)=sampleDirMat(sufstat{1}(:,r)',1)';
        V(:,r)=gamrnd(sufstat{2}(:,r),qr(r));
    end
    qr=betarnd(c*epsi+sufstat{3},c*(1-epsi)+ND*s);
    eval(iter)=loglike(xitest,idtest,U,V);
    timeintvl=toc;
    fprintf('iteration= %d;loglikelihood= %f,timePerIter=%f\n', iter, eval(iter),timeintvl);
    
end

W_outputN=20;
WO=vocabulary;
[Topics]=OutputTopics(U,WO,W_outputN)