testfrac=0.1;
[xitrain, idtrain, xitest,idtest]=datasplit(xi,id,testfrac);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%parameter init
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ND=max(idtrain(:,1));%# of docs
NW=max(idtrain(:,2));%# of words
alpha=0.1;R=50;
U = sampleDirMat(alpha*ones(1,NW),R)';
c=1;epsi=1/R;
% qr=betarnd(c*epsi*ones(1,R),c*(1-epsi)*ones(1,R));
qr=0.5*ones(1,R);
% qr=0.1*ones(1,R);
% qr=betarnd(c*epsi*ones(1,R),c*(1-epsi)*ones(1,R));
s=1;beta1=1;beta0=1;
Naff=size(affid2aid,1);
F=gamrnd(s,1/beta1,Naff,R);% affiliation feature
NF=size(aid2docid,1);%# of falcuty

Df=zeros(NF,1);
for i=1:NF
    Df(i)=aid2docnum(num2str(i));
end


G=zeros(NF,R);%falcuty feature
for i=1:NF
    affidx=aid2affid(num2str(i));
    sGtmp=zeros(1,R);
    for j=1:length(affidx)
        sGtmp=sGtmp+F(affidx(j),:);
    end
    G(i,:)=sGtmp/Df(i);%gamrnd(sGtmp,1/beta0/Df(i));
end
V=zeros(ND,R);
Vjrf=cell(1,ND);
for i=1:ND
    aidx=doc2aid(num2str(i));
    sVcurrent=zeros(1,R);
    Vjrf{i}=zeros(length(aidx),R);
    for j=1:length(aidx)
        sVcurrent=G(aidx(j),:);
%         sVtmp=sVtmp+sVcurrent;
        Vjrf{i}(j,:)=gamrnd(sVcurrent,qr/(1-qr));
    end
%     V(i,:)=gamrnd(sVtmp,qr/(1-qr));
    V(i,:)=sum(Vjrf{i},1);
end

iterMax=100;
aidx_cell=docauthorsearch(doc2aid,ND);

ell_fr=zeros(NF,R);
ell_ar=zeros(Naff,R);
eval=zeros(1,iterMax);
for iter=1:iterMax
    tic    
    sufstat=computeSufStat(xitrain,idtrain,U,V,Vjrf,alpha,G,NF,aidx_cell);
    for r=1:R
        U(:,r)=sampleDirMat(sufstat{1}(:,r)',1)';
%         V(:,r)=gamrnd(sufstat{2}(:,r),qr(r));
    end
    for i=1:ND
        Vjrfshape=sufstat{2}{i};
        Vjrf{i}=gamrnd(Vjrfshape,repmat(qr,size(Vjrfshape,1),1));
        V(i,:)=sum(Vjrf{i},1);
    end
    qr=betarnd(c*epsi+sufstat{3},c*(1-epsi)+sufstat{4});
    Gs=zeros(NF,R);%shape parameter for G
    for i=1:NF
        affidxtmp=aid2affid(num2str(i));
        for j=1:length(affidxtmp)
            Gs(i,:)=Gs(i,:)+F(affidxtmp(j),:);
        end
    end
    
    for i=1:NF
        ell_fr(i,:)=CRT(sufstat{5}(i,:),Df(i)*G(i,:));
        for r=1:R
%             ell_fr(i,r) = CRT_sum_mex(sufstat{5}(i,r),Df(i)*G(i,r));
%             ell_fr(i,r) = CRT(sufstat{5}(i,r),Df(i)*G(i,r));
            G(i,r)=gamrnd(Gs(i,r)+ell_fr(i,r),1/(beta0-Df(i)*log(1-qr(r))));
        end
    end
    ell_ar_firstpara=zeros(Naff,R);
    for i=1:Naff
        aidxtmp=affid2aid(num2str(i));
        for j=1:length(aidxtmp)
            ell_ar_firstpara(i,:)=ell_ar_firstpara(i,:)+ell_fr(aidxtmp(j),:);
        end
    end
    for i=1:Naff
        ell_ar(i,:)=CRT(ell_ar_firstpara(i,:),F(i,:));
%         for r=1:R
%             ell_ar(i,r)=CRT_sum_mex(ell_ar_firstpara(i,r),F(i,r));
%         end
    end
    Qr=-log(1-qr)./(beta0-log(1-qr));
    for i=1:Naff
        anumtmp=affid2anum(num2str(i));
        F(i,:)=gamrnd(s+ell_ar(i,:),1./(beta1-anumtmp*log(1-Qr)));
    end
    eval(iter)=loglike(xitest,idtest,U,V);
    timeintvl=toc;
    fprintf('iteration= %d;loglikelihood= %f,timePerIter=%f\n', iter, eval(iter),timeintvl);
    
end

W_outputN=20;
WO=vocabulary;
[Topics]=OutputTopics(U,WO,W_outputN)

Gnorm=G./(repmat(sqrt(sum(G.^2,2)),1,R));
% Gnorm=G;
GG=1-pdist2(Gnorm,Gnorm,'cosine');
% GG=pdist2(Gnorm,Gnorm);
% GG=G*G';
% FF=F*F';
simN=20;
aidsearch=3;%621;%1130;%621;%1131;
% [simval aidout]=sort(GG(aidsearch,:),'ascend');
[simval aidout]=sort(GG(aidsearch,:),'descend');
for i=1:simN
    strFalAff=[aid2did(num2str(aidout(i)))];%[did2name(num2str(aid2did(num2str(aidout(i)))))];
    affidtmp=aid2affid(num2str(aidout(i)));
    for j=1:length(affidtmp)
        strFalAff=[strFalAff,', ',id2aff(num2str(affidtmp(j)))];
    end
    disp(strFalAff);
end

% factorid=1;
% simN=6;
% [gval gidout]=sort(G(:,factorid),'descend');
% for i=1:simN
%     strFalAff=[aid2did(num2str(aidout(i)))];;
%     affidtmp=aid2affid(num2str(gidout(i)));
%     for j=1:length(affidtmp)
%         strFalAff=[strFalAff,' ',id2aff(num2str(affidtmp(j)))];
%     end
%     disp(strFalAff);
% end

% factorid=15;
% [fval fidout]=sort(F(:,factorid),'descend');
% for i=1:simN
%     disp(id2aff(num2str(fidout(i))));
% end

Fnorm=F./(repmat(sqrt(sum(F.^2,2)),1,R));
FF=1-pdist2(Fnorm,Fnorm,'cosine');
affidsearch=2;%25;%13;%79;%144;%1;%116;%158;%196;%200;%83;%116;
[simval fidout]=sort(FF(affidsearch,:),'descend');
for i=1:6
    disp(id2aff(num2str(fidout(i))));
end

FG=1-pdist2(Fnorm,Gnorm,'cosine');
partysearch=6;
[fgval aidout]=sort(FG(partysearch,:),'descend');
for i=1:20
    strFalAff=[aid2did(num2str(aidout(i)))];%[did2name(num2str(aid2did(num2str(aidout(i)))))];
    affidtmp=aid2affid(num2str(aidout(i)));
    for j=1:length(affidtmp)
        strFalAff=[strFalAff,', ',id2aff(num2str(affidtmp(j)))];
    end
    disp(strFalAff);
end

presidentsearch=13;
[fgval partyidout]=sort(FG(:,presidentsearch),'descend');
disp([aid2did(num2str(presidentsearch)),', ',id2aff(num2str(aid2affid(num2str(presidentsearch))))]);
for i=1:6   
    disp(id2aff(num2str(partyidout(i))));
end

for i=1:6
    disp(id2aff(num2str((i))));
end

AP=zeros(41,6);
APmax=zeros(41,6);
APmax2item=zeros(41,6);
for i=1:41
    j=aid2affid(num2str(i));
    AP(i,j)=1;    
    [val,jid]=sort(FG(:,i),'descend');
    APmax(i,jid(1))=FG(jid(1),i);
    APmax2item(i,jid(1))=FG(jid(1),i);
    APmax2item(i,jid(2))=FG(jid(2),i);
end

for affidsearch=1:6;
disp('------------------------')
disp(id2aff(num2str(affidsearch)));
[fval fidout]=sort(F(affidsearch,:).*qr,'descend');
for i=1:5
    if qr(fidout(i))>0
    disp(Topics{fidout(i)});
    end
end
end