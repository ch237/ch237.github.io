clear all;close all;
% [vnum,vtext,sheet]=xlsread('/Users/changwei/Documents/Research/data/StateoftheUnion/Presidents.xlsx');
% 
% did2id=containers.Map;%map president name to fake id
% aid2did=containers.Map;%map fake id to president name
% % doc2anum=containers.Map;%map doc id to number of authors
% doc2aid=containers.Map;%map doc id to author fake id
% aid2docid=containers.Map;%map from author fake id to id of documents this author wrote
% aid2docnum=containers.Map;%map from author fake id to the number of documents this author wrote
% % did2name=containers.Map;
% aff2id=containers.Map;%map from party to party fake id 
% id2aff=containers.Map;%map from party fake id to party
% aid2affid=containers.Map;% map from president fake id to party id
% affid2anum=containers.Map;%map from party id to number of presidents associated with it
% affid2aid=containers.Map;% map from affiliation id to president fake id
% 
% 
% docPointer=0;
% partyCount=1;
% pidx=1;%president index
% for i_=2:(size(sheet,1)-2)%pass the head and the last two people with no speech
%     i=i_-1;
%     aname=sheet(i_,1);
%     aname=aname{1};
%     dnum=sheet(i_,2);
%     dnum=dnum{1};
%     pname=sheet(i_,3);%party name
%     pname=pname{1};
%     if ~isKey(did2id,aname)
%         did2id(aname)=pidx;
%         aid2did(num2str(pidx))=aname;
%         pidx=pidx+1;       
%     end
%     
% %     did2id(aname)=i;
% %     aid2did(num2str(i))=aname;
%     docidx=[docPointer+1:docPointer+dnum];
%     docPointer=docPointer+dnum;
%     pidtmp=did2id(aname);
%     for j=1:length(docidx)
%         doc2aid(num2str(docidx(j)))=pidtmp;
%     end
%     if ~isKey(aid2docid,num2str(pidtmp))
%         aid2docid(num2str(pidtmp))=docidx;
%         aid2docnum(num2str(pidtmp))=length(docidx);
%     else
%         aid2docid(num2str(pidtmp))=[aid2docid(num2str(pidtmp)),docidx];
%         aid2docnum(num2str(pidtmp))=aid2docnum(num2str(pidtmp))+length(docidx);
%     end
%     
%     if ~isKey(aff2id,pname)
%         aff2id(pname)=partyCount;
%         id2aff(num2str(partyCount))=pname;
%         partyCount=partyCount+1;
%     end
%     affid=aff2id(pname);
%     aid2affid(num2str(pidtmp))=affid;
%     if ~isKey(affid2anum,num2str(affid))
%         affid2anum(num2str(affid))=1;
%         affid2aid(num2str(affid))=pidtmp;
%     else
%         if ~any(affid2aid(num2str(affid))==pidtmp)
%         affid2anum(num2str(affid))=affid2anum(num2str(affid))+1;
%         affid2aid(num2str(affid))=[affid2aid(num2str(affid)),pidtmp];
%         end
%     end
% end
% 
% load /Users/changwei/Documents/Research/data/StateoftheUnion/STOU.mat
% vocabulary=STOU.words;
% for i=1:length(vocabulary)
%     vocabulary{i}=lower(vocabulary{i});
% end
% [rows, cols, vals]=find(STOU.WCmatrix);
% 
% id=[cols,rows];
% xi=vals;
% save stou_xiid xi id vocabulary did2id aid2did doc2aid aid2docid aid2docnum aff2id id2aff aid2affid affid2anum affid2aid
load stou_xiid
hierarchical_onelayer
% hierarchical;
% nonhierarchical;