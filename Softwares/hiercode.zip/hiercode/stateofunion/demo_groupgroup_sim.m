% clear all;
% load('results_hier_final.mat')
load('results_onelayer_final.mat')
G_reorder=zeros(size(G));
order=zeros(20,1);
idx=0;
for i=1:6
    rowid=affid2aid(num2str(i));
    N=length(rowid);
    for j=1:N
        G_reorder(idx+j,:)=G(rowid(j),:);
        order(idx+j)=rowid(j);
    end
    idx=idx+N;
end


Gnorm_reorder=G_reorder./(repmat(sqrt(sum(G_reorder.^2,2)),1,R));
GG_reorder=1-pdist2(Gnorm_reorder,Gnorm_reorder,'cosine');

figure,imagesc(GG_reorder)
colorStr=['k','m','y','r','g','b','c'];
for i_=1:41
    i=order(i_);
%     splitStr=strsplit(labelsToGroup{i},'.');
    splitStr=strsplit(aid2did(num2str(i)),' ');
    affidtmp=aid2affid(num2str(i));
    afftmp=id2aff(num2str(affidtmp));
    colortmp=colorStr(affidtmp);
    if affidtmp==3
        colortmp=[0.3,0.5,1];
    elseif affidtmp==1
        colortmp=[0.5,0.8,0.7];
    end
    text(-3.5,i_,[num2str(affidtmp)],'fontsize',13,'color',colortmp);
    if i==8
        text(-3,i_,[splitStr(end-1)],'fontsize',13,'fontweight','bold','color',colortmp);
    else
        text(-3,i_,[,splitStr(end)],'fontsize',13,'fontweight','bold','color',colortmp);
    end
%     text(-2,i,[num2str(affidtmp),': ',splitStr{end-1},'.',splitStr{end}],'fontsize',12,'fontweight','bold','color',colortmp);
%     text(i-0.4,0,[num2str(i)],'fontsize',12,'fontweight','bold','color',colortmp);
end
set(gca,'ytick',[])
set(gca,'xtick',[])




% FG_reorder=1-pdist2(Fnorm,Gnorm_reorder,'cosine');
% figure,imagesc(FG_reorder')
% colorStr=['k','m','y','r','g','b','c'];
% for i_=1:41
% %     splitStr=strsplit(labelsToGroup{i},'.');
%     i=order(i_);
%     splitStr=strsplit(aid2did(num2str(i)),' ');
%     affidtmp=aid2affid(num2str(i));
%     afftmp=id2aff(num2str(affidtmp));
%     colortmp=colorStr(affidtmp);
%     if affidtmp==3
%         colortmp=[0.3,0.5,1];
%     elseif affidtmp==1
%         colortmp=[0.5,0.8,0.7];
%     end
%     text(-0.6,i_,[num2str(affidtmp)],'fontsize',16,'color',colortmp);
%     if i==8
%         text(-0.5,i_,[splitStr(end-1)],'fontsize',16,'color',colortmp);
%     else
%         text(-0.5,i_,[splitStr(end)],'fontsize',16,'color',colortmp);
%     end
% %     text(-2,i,[num2str(affidtmp),': ',splitStr{end-1},'.',splitStr{end}],'fontsize',12,'fontweight','bold','color',colortmp);
% %     text(i-0.4,0,[num2str(i)],'fontsize',12,'fontweight','bold','color',colortmp);
% end
% for i=1:6
%     colortmp=colorStr(i);
%     afftmp=id2aff(num2str(i));
%     if i==3
%         colortmp=[0.3,0.5,1];
%         afftmp='Dem-Rep'
%     elseif i==1
%         colortmp=[0.5,0.8,0.7];
%     end
%     text(i-0.4,-0.7,[afftmp],'fontsize',16,'color',colortmp);
% end
% set(gca,'ytick',[])
% set(gca,'xtick',[])
