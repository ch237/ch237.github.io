clear all;close all;
[rows, cols]=textread('/Users/changwei/Documents/Research/data/citeseer_cora/data/citeseer/citeseerlinks.txt','%d%d');
% LinkMatrix=Cgenerate(rows,cols);
% save LinkMatrix

% load('/Users/changwei/Documents/Research/data/cora_matlab/CoraData_LiseGetoor.mat')
% [rows,cols,xi]=find(LinkMatrix);
% id=[cols,rows];
% labels=VecLabel;
% labelsToGroup=CellLabelMap;
load LinkMatrix
id=[cols,rows];
xi=ones(length(cols),1);
[doc,labels]=textread('/Users/changwei/Documents/Research/data/citeseer_cora/data/citeseer/citeseerlabels.txt','%d%d');
[cat,labelsToGroup]=textread('/Users/changwei/Documents/Research/data/citeseer_cora/data/citeseer/labels.txt','%d%s');
doc2aid=containers.Map;
% X=LinkMatrix;
% F=zeros(size(X,1),max(labels));
% for i=1:length(labels)
%     F(i,labels(i))=1;
% end
aid2docid=containers.Map;
aid2docnum=containers.Map;
for i=1:length(labels)
    doc2aid(num2str(i))=labels(i);
    if ~isKey(aid2docid,num2str(labels(i)))
        aid2docid(num2str(labels(i)))=i;
        aid2docnum(num2str(labels(i)))=1;
    else
        aid2docid(num2str(labels(i)))=[aid2docid(num2str(labels(i))),i];
        aid2docnum(num2str(labels(i)))=aid2docnum(num2str(labels(i)))+1;
    end
end
 
save citeseer_xiid xi id doc2aid aid2docid aid2docnum labelsToGroup
load citeseer_xiid
hierarchical_onelayer;
% nonhierarchical