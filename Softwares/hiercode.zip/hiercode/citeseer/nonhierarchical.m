testfrac=0.1;
[xitrain, idtrain, xitest,idtest]=datasplit(xi,id,testfrac);
[zeroID1,zeroID2] = ind2sub(size(LinkMatrix),find(LinkMatrix== 0));
zeroRatio=1;
zeroN=floor(length(xitest)*zeroRatio);
rand('state',0);%generate same randome numbers each time
zeroIDid=randperm(length(zeroID1));
zeroIDid=zeroIDid(1:zeroN);
idtestadd=[zeroID2(zeroIDid),zeroID1(zeroIDid)];
idtest=[idtest;idtestadd];
xitest=[xitest;zeros(zeroN,1)];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%parameter init
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ND=size(LinkMatrix,2);%max(id(:,1));%# of docs
NW=size(LinkMatrix,1);%# of words

alpha=0.1;R=50;
U = sampleDirMat(alpha*ones(1,NW),R)';
c=1;epsi=1/R;
qr=betarnd(c*epsi*ones(1,R),c*(1-epsi)*ones(1,R));
% qr=0.5*ones(1,R);
% qr=betarnd(c*epsi*ones(1,R),c*(1-epsi)*ones(1,R));
V=zeros(ND,R);
s=1;
for i=1:ND
    V(i,:)=gamrnd(s,qr/(1-qr));
end

iterMax=100;
llikevec=zeros(iterMax,1);
rmsevec=zeros(iterMax,1);
maevec=zeros(iterMax,1);
msevec=zeros(iterMax,1);
auc=zeros(iterMax,1);
auc_pr=zeros(iterMax,1);
for iter=1:iterMax
    tic    
    sufstat=computeSufStat_nohierarch(xitrain,idtrain,U,V,alpha);
    for r=1:R
        U(:,r)=sampleDirMat(sufstat{1}(:,r)',1)';
        V(:,r)=gamrnd(sufstat{2}(:,r),qr(r));
    end
    qr=betarnd(c*epsi+sufstat{3},c*(1-epsi)+ND*s);
    [llike mae rmse mse auc_test auc_pr_test zetaitest_tmp]=evaluation_zetai(xitest,idtest,U,V);
    llikevec(iter)=llike;rmsevec(iter)=rmse;maevec(iter)=mae;msevec(iter)=mse;auc(iter)=auc_test;auc_pr(iter)=auc_pr_test;
    fprintf('iter= %d;loglike= %f, mae=%f, mse=%f, rmse=%f, auc=%f, auc_pr=%f\n', iter, llike, mae, mse, rmse, auc_test,auc_pr_test);
    
end