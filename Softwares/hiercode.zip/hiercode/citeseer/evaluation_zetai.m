function [llike mae rmse mse auc_test auc_test2 zetai]=evaluation_zetai(xi,id,U,V)


R=size(U,2);
Np=length(xi);
zetai=sum(U(id(:,2),:).*V(id(:,1),:),2)+eps;
llike = sum(xi.*log(1-exp(-zetai)) - (1-xi).*zetai);
rmse=norm(xi-(1-exp(-zetai)),'fro')/(sqrt(size(xi,1) * size(xi,2)));
mae=sum(abs(xi-(1-exp(-zetai))))/Np;
mse=rmse^2;
auc_test = compute_AUC(xi,1-exp(-zetai),ones(1,length(xi)));
[prec, tpr, fpr, thresh] = prec_rec(1-exp(-zetai), xi);
auc_test2 = trapz([0;tpr],[1;prec]);
zetai=1-exp(-zetai);
% auc_test = compute_AUC(xi,zetai,ones(1,length(xi)));

% errornorm2=sum((xi-zetai).^2)/Np;%sum(xi.^2);
