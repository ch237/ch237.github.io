function llike=loglike(xi,id,U,V)
R=size(U,2);
Np=length(xi);
zetai=zeros(Np,1);
for i=1:Np
    zetai(i)=sum(U(id(i,2),:).*V(id(i,1),:));
end
llike=sum(-zetai+xi.*log(zetai));
