function sufstat=computeSufStat_nohierarch(xi,id,U,V,alpha)
     NW=size(U,1);
     ND=size(V,1);
     R=size(V,2);
     sufstat=cell(1,5);
     sufstat{1}=zeros(NW,R)+alpha;%update topics(dirichelet)
     sufstat{2}=zeros(ND,R);%update topic proportion
     sufstat{3}=zeros(1,R);%update qr
     
     for i=1:length(xi)
         idx1=id(i,1);
         idx2=id(i,2);
         multpara=U(idx2,:).*V(idx1,:)+eps;
         multpara_sum=sum(multpara);
         xicount=truncated_Poisson_rnd_1(1,multpara_sum);
         multpara=multpara./multpara_sum;
         counttmp=mnrnd(xicount,multpara);
         sufstat{1}(idx2,:)=sufstat{1}(idx2,:)+counttmp;
         sufstat{2}(idx1,:)=sufstat{2}(idx1,:)+counttmp;
        
     end
     sufstat{3}=sum(sufstat{2});
end