function sufstat=computeSufStat(xi,id,U,V,Vjrf,alpha,G,NF,aidx_cell)
     NW=size(U,1);
     ND=size(V,1);
     R=size(V,2);
     sufstat=cell(1,5);
     sufstat{1}=zeros(NW,R)+alpha;%update topics(dirichelet)
%      sufstat{2}=zeros(ND,R);%update topic proportion
     sufstat{2}=cell(1,ND);
     sufstat{3}=zeros(1,R);%update qr
     sufstat{5}=zeros(NF,R);%sum X_dot,j,r,f over j\in D_f
%      aidx_cell=cell(1,ND);
     sufstat{4}=zeros(1,R);


     for i=1:ND
        aidx=aidx_cell{i};
        sufstat{2}{i}=zeros(length(aidx),R);%shape parameter for update V_{jrf}
        for j=1:length(aidx)
            sufstat{2}{i}(j,:)=G(aidx(j),:);
        end
        sufstat{4}=sufstat{4}+sum(sufstat{2}{i},1);
     end
     

%      for i=1:ND
%         aidx=aidx_cell{i};
%         sVtmp=zeros(1,R);
%         for j=1:length(aidx)
%             sVtmp=sVtmp+G(aidx(j),:);
%         end
%         sufstat{2}(i,:)=sVtmp;
% %         aidx_cell{i}=aidx;
%      end
     
     for i=1:length(xi)
         idx1=id(i,1);
         idx2=id(i,2);
         multpara=U(idx2,:).*V(idx1,:)+eps;
         multpara_sum=sum(multpara);
         xicount=truncated_Poisson_rnd_1(1,multpara_sum);
         multpara=multpara./multpara_sum;
         counttmp=mnrnd(xicount,multpara);
         sufstat{1}(idx2,:)=sufstat{1}(idx2,:)+counttmp;
%          sufstat{2}(idx1,:)=sufstat{2}(idx1,:)+counttmp;
         idnonzero=find(counttmp~=0);
         aidxtmp=aidx_cell{idx1};
         vjrftmp=Vjrf{idx1};
         for j_=1:length(idnonzero)
             j=idnonzero(j_);
             gtmp=vjrftmp(:,j)+eps;
             gtmp=gtmp/sum(gtmp);
             counttmptmp=mnrnd(counttmp(j),gtmp);
             sufstat{5}(aidxtmp,j)=sufstat{5}(aidxtmp,j)+counttmptmp';
             sufstat{2}{idx1}(:,j)=sufstat{2}{idx1}(:,j)+counttmptmp';
         end         
     end
%      sufstat{3}=sum(sufstat{2});
     sufstat{3}=sum(sufstat{1})-NW*alpha;
     
     
%      for i=1:length(xi)
%          idx1=id(i,1);
%          idx2=id(i,2);
%          multpara=U(idx2,:).*V(idx1,:);
%          multpara=multpara./sum(multpara);
%          counttmp=mnrnd(xi(i),multpara);
%          sufstat{1}(idx2,:)=sufstat{1}(idx2,:)+counttmp;
%          sufstat{2}(idx1,:)=sufstat{2}(idx1,:)+counttmp;
% %          sufstat{3}= sufstat{3}+counttmp;
%          idnonzero=find(counttmp~=0);
%          aidxtmp=aidx_cell{idx1};
%          vjrftmp=Vjrf{idx1};
%          for j_=1:length(idnonzero)
%              j=idnonzero(j_);
% %              aidxtmp=doc2aid(num2str(idx1));
% %              gtmp=G(aidxtmp,j)';
% %              gtmp=gamrnd(gtmp,1);
% %              gtmp=gtmp/sum(gtmp);
%              gtmp=vjrftmp/sum(vjrftmp);
%              counttmptmp=mnrnd(counttmp(j),gtmp);
%              sufstat{5}(aidxtmp,j)=sufstat{5}(aidxtmp,j)+counttmptmp';
%          end         
%      end
%      sufstat{3}=sum(sufstat{2});
end