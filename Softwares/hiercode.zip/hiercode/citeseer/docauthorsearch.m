function aidx_cell=docauthorsearch(doc2aid,ND)
    aidx_cell=cell(1,ND);
    for i=1:ND
        aidx=doc2aid(num2str(i));
        aidx_cell{i}=aidx;
     end
end