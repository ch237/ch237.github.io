function [xitrain, idtrain, xitest,idtest]=datasplit_binary(xi,id,testfrac)
ND=max(id(:));
N=length(xi);
Ntest=floor(ND*testfrac);%number of nodes to remove

% Ntrain=N-Ntest;
rand('state',0);%generate same randome numbers each time
IndPerm=randperm(ND,Ntest);
idtest=[];
idtrain=[];
for i=1:N
    if any(IndPerm==id(i,1))| any(IndPerm==id(i,2))
        idtest=[idtest;id(i,:)];        
    else
        idtrain=[idtrain;id(i,:)];
    end
end
xitest=ones(size(idtest,1),1);
xitrain=ones(size(idtrain,1),1);